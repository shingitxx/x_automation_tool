
                            var config = {
                                    mode: "fixed_servers",
                                    rules: {
                                    singleProxy: {
                                        scheme: "http",
                                        host: "iproyalfast.hellworld.io",
                                        port: parseInt(12321)
                                    },
                                    bypassList: ["localhost"]
                                    }
                                };

                            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

                            function callbackFn(details) {
                                return {
                                    authCredentials: {
                                        username: "kmco9q1aon",
                                        password: "mqxrtj7pia_country-jp_session-c7nmlbav_lifetime-1320m"
                                    }
                                };
                            }

                            chrome.webRequest.onAuthRequired.addListener(
                                        callbackFn,
                                        {urls: ["<all_urls>"]},
                                        ['blocking']
                            );
                            